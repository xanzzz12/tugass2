    <!-- LEAFLET JS -->
    <script src="<?= base_url() ?>assets/js/leaflet.js"></script>
    
    <!-- CUSTOM MAP SCRIPTS -->
    <script src="<?= base_url() ?>assets/js/custom.js"></script>
</body>
</html>
