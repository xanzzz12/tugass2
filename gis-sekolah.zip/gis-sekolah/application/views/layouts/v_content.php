<?php
if ($isi) 
{
    $this->load->view($isi);
}
?>